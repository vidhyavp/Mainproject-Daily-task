﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace WebAppMVC.Models
{
    public class Student
    {
        [Required(ErrorMessage = "This field is Required")]
        [Display(Name="Enter your Name")]
        //[RegularExpression()]
        public string sname { get; set; }

        [Required(ErrorMessage="This field is Required")]
        [Display(Name="Enter your Address")]
        [DataType(DataType.MultilineText)]
        public string saddress { get; set; }

        [Required(ErrorMessage = "This field is Required")]
        [Display(Name="enter your Email")]
        [DataType(DataType.EmailAddress)]
        public string semail { get; set; }


        [Required(ErrorMessage = "This field is Required")]
        public string Gender { get; set; }


        [Required(ErrorMessage = "This field is Required")]
        [Display(Name = "Course")]
        public Course courseList { get; set; }


        [Required(ErrorMessage = "This field is Required")]
        [Display(Name = "username")]
        public string Username { get; set; }


        [Required(ErrorMessage = "This field is Required")]
        [Display(Name = "password")]
        [DataType(DataType.Password)]
        public string password { get; set; }

        [Required(ErrorMessage = "This field is Required")]
        [Display(Name = "Confirm-Password")]
        [DataType(DataType.Password)]
        public string confirmPass { get; set; }


        public bool isAgree { get; set; }

    }

    public enum Course
    {
        MCA,
        BCA,
        Integrated_MCA,
      
    }


}
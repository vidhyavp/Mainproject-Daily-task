﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(samp.Startup))]
namespace samp
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}

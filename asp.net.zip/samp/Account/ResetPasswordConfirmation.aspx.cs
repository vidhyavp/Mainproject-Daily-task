﻿using System.Web.UI;

namespace samp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}